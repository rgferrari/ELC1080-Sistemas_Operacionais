# Trabalho 1 - Sistemas Operacionais A (ELC1080)

Aluno: René Gargano Ferrari
Matrícula: 201812031
Turma: CC

Para compilar o código:
gcc -o gerador_de_dicas gerador_de_dicas.c funcs.c funcs.h

